#!/bin/bash
echo "Start of the script for creating graphs"


name="$1" #Имя теста
modes="$2" # режимы s, c, m  - single, copy, mirror
tools="$3" # инструменты 01, 0, 1
axes="$4" #Оси теста xy, x, y

echo "name: "$name""
echo "modes: "$modes""
echo "tools: "$tools""
echo "axes: "$axes""



DATE=$(date +'%Y-%m-%d-%H:%M')
NAME_FOLDER="$DATE"_"$name"

# Создание папки с названием "name" по пути ~/printer_data/config/
mkdir -p ~/printer_data/config/shaper/"$NAME_FOLDER"

for mode in $(echo "$modes" | grep -o .); do
	for tool in $(echo "$tools" | grep -o .); do
		for axis in $(echo "$axes" | grep -o .); do

			NAME_FILE="$name"_"$mode"_"$tool"_"$axis"
			if [ ! -e "/tmp/resonances_"$axis"_"$NAME_FILE".csv" ]
					then
						echo "ERROR: No data found for /tmp/resonances_"$axis"_"$NAME_FILE".csv"
						exit 1
					fi
					cp /tmp/resonances_"$axis"_"$NAME_FILE".csv ~/printer_data/config/shaper/"$NAME_FOLDER"/"$NAME_FILE".csv
					echo "please wait..."
					/home/pi/klipper/scripts/calibrate_shaper.py ~/printer_data/config/shaper/"$NAME_FOLDER"/"$NAME_FILE".csv -o ~/printer_data/config/shaper/"$NAME_FOLDER"/"$NAME_FILE".png

					#rm /tmp/resonances_"$axis"_"$NAME_FILE".csv #удалить исходник
		done
	done
done



